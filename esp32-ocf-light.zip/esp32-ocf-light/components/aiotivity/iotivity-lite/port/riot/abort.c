#include "port/oc_assert.h"

// TODO:
void abort_impl(void) {}
