/*
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 Copyright 2017-2019 Open Connectivity Foundation
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

/* Application Design
*
* support functions:
* app_init
*  initializes the oic/p and oic/d values.
* register_resources
*  function that registers all endpoints, e.g. sets the RETRIEVE/UPDATE handlers for each end point
*
* main 
*  starts the stack, with the registered resources.
*
* Each resource has:
*  global property variables (per resource path) for:
*    the property name
*       naming convention: g_<path>_RESOURCE_PROPERTY_NAME_<propertyname>
*    the actual value of the property, which is typed from the json data type
*      naming convention: g_<path>_<propertyname>
*  global resource variables (per path) for:
*    the path in a variable:
*      naming convention: g_<path>_RESOURCE_ENDPOINT
*    array of interfaces, where by the first will be set as default interface
*      naming convention g_<path>_RESOURCE_INTERFACE
*
*  handlers for the implemented methods (get/post)
*   get_<path>
*     function that is being called when a RETRIEVE is called on <path>
*     set the global variables in the output
*   post_<path>
*     function that is being called when a UPDATE is called on <path>
*     checks the input data
*     if input data is correct
*       updates the global variables
*
*/
/*
 tool_version          : 20171123
 input_file            : ../device_output/out_codegeneration_merged.swagger.json
 version of input_file : 20190222
 title of input_file   : Binary Switch
*/

#include "oc_api.h"
#include "port/oc_clock.h"
#include <signal.h>

#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

//#include "nvs.h"
#include "nvs_flash.h"
//#include "esp_wifi.h"
#include "esp_event_loop.h"
#include "esp_log.h"

#include "esp_eth.h"
#include "olimex_ethernet.h"
#include "eth_phy/phy_lan8720.h"

#include "lightbulb.h"
//#include "debug_print.h"


/* linux specific code */
#include <pthread.h>
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
//static pthread_mutex_t mutex;
//static pthread_cond_t cv;
static struct timespec ts;

#define MAX_STRING 30           /* max size of the strings. */
#define MAX_PAYLOAD_STRING 65   /* max size strings in the payload */
#define MAX_ARRAY 10            /* max size of the array */
/* Note: Magic numbers are derived from the resource definition, either from the example or the definition.*/

volatile int quit = 0;          /* stop variable, used by handle_signal */
static const int IPV4_CONNECTED_BIT = BIT0;
static const int IPV6_CONNECTED_BIT = BIT1;


/* global property variables for path: "/binaryswitch" */
static char g_binaryswitch_RESOURCE_PROPERTY_NAME_value[] = "value"; /* the name for the attribute */
bool g_binaryswitch_value = false; /* current value of property "value" The status of the switch. */
/* global property variables for path: "/dimmingcold" */
static char g_dimmingcold_RESOURCE_PROPERTY_NAME_dimmingSetting[] = "dimmingSetting"; /* the name for the attribute */
int g_dimmingcold_dimmingSetting = 30; /* current value of property "dimmingSetting" The current dimming value. */
/* global property variables for path: "/dimmingwarm" */
static char g_dimmingwarm_RESOURCE_PROPERTY_NAME_dimmingSetting[] = "dimmingSetting"; /* the name for the attribute */
int g_dimmingwarm_dimmingSetting = 30; /* current value of property "dimmingSetting" The current dimming value. *//* registration data variables for the resources */

/* global resource variables for path: /binaryswitch */
static char g_binaryswitch_RESOURCE_ENDPOINT[] = "/binaryswitch"; /* used path for this resource */
static char g_binaryswitch_RESOURCE_TYPE[][MAX_STRING] = {"oic.r.switch.binary"}; /* rt value (as an array) */
int g_binaryswitch_nr_resource_types = 1;
static char g_binaryswitch_RESOURCE_INTERFACE[][MAX_STRING] = {"oic.if.baseline","oic.if.a"}; /* interface if (as an array) */
int g_binaryswitch_nr_resource_interfaces = 2;

/* global resource variables for path: /dimmingcold */
static char g_dimmingcold_RESOURCE_ENDPOINT[] = "/dimmingcold"; /* used path for this resource */
static char g_dimmingcold_RESOURCE_TYPE[][MAX_STRING] = {"oic.r.light.dimming"}; /* rt value (as an array) */
int g_dimmingcold_nr_resource_types = 1;
static char g_dimmingcold_RESOURCE_INTERFACE[][MAX_STRING] = {"oic.if.baseline","oic.if.a"}; /* interface if (as an array) */
int g_dimmingcold_nr_resource_interfaces = 2;

/* global resource variables for path: /dimmingwarm */
static char g_dimmingwarm_RESOURCE_ENDPOINT[] = "/dimmingwarm"; /* used path for this resource */
static char g_dimmingwarm_RESOURCE_TYPE[][MAX_STRING] = {"oic.r.light.dimming"}; /* rt value (as an array) */
int g_dimmingwarm_nr_resource_types = 1;
static char g_dimmingwarm_RESOURCE_INTERFACE[][MAX_STRING] = {"oic.if.baseline","oic.if.a"}; /* interface if (as an array) */
int g_dimmingwarm_nr_resource_interfaces = 2;
/**
* function to set up the device.
*
*/
static int
app_init(void)
{
  int ret = oc_init_platform("ocf", NULL, NULL);
  /* the settings determine the appearance of the device on the network
     can be OCF1.3.1 or OCF2.0.0 (or even higher)
     supplied values are for OCF1.3.1 */
  ret |= oc_add_device("/oic/d", "oic.d.light", "Binary Switch", 
                       "ocf.1.0.0", /* icv value */
                       "ocf.res.1.3.0, ocf.sh.1.3.0",  /* dmv value */
                       NULL, NULL);
  return ret;
}

/**
* helper function to convert the interface string definition to the constant defintion used by the stack.
* @param interface the interface string e.g. "oic.if.a"
* @return the stack constant for the interface
*/
static int
convert_if_string(char *interface_name)
{
  if (strcmp(interface_name, "oic.if.baseline") == 0) return OC_IF_BASELINE;  /* baseline interface */
  if (strcmp(interface_name, "oic.if.rw") == 0) return OC_IF_RW;              /* read write interface */
  if (strcmp(interface_name, "oic.if.r" )== 0) return OC_IF_R;                /* read interface */
  if (strcmp(interface_name, "oic.if.s") == 0) return OC_IF_S;                /* sensor interface */
  if (strcmp(interface_name, "oic.if.a") == 0) return OC_IF_A;                /* actuator interface */
  if (strcmp(interface_name, "oic.if.b") == 0) return OC_IF_B;                /* batch interface */
  if (strcmp(interface_name, "oic.if.ll") == 0) return OC_IF_LL;              /* linked list interface */
  return OC_IF_A;
}

 
/**
* get method for "/binaryswitch" resource.
* function is called to intialize the return values of the GET method.
* initialisation of the returned values are done from the global property values.
* Resource Description:
* This Resource describes a binary switch (on/off).
* The Property "value" is a boolean.
* A value of 'true' means that the switch is on.
* A value of 'false' means that the switch is off.
*
* @param request the request representation.
* @param interfaces the interface used for this call
* @param user_data the user data.
*/
static void
get_binaryswitch(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)user_data;  /* not used */
  /* TODO: SENSOR add here the code to talk to the HW if one implements a sensor.
     the call to the HW needs to fill in the global variable before it returns to this function here.
     alternative is to have a callback from the hardware that sets the global variables.
  
     The implementation always return everything that belongs to the resource.
     this implementation is not optimal, but is functionally correct and will pass CTT1.2.2 */
  
  PRINT("get_binaryswitch: interface %d\n", interfaces);
  oc_rep_start_root_object();
  switch (interfaces) {
  case OC_IF_BASELINE:
    /* fall through */
  case OC_IF_A:
  PRINT("   Adding Baseline info\n" );
    oc_process_baseline_interface(request->resource);
    /* property "value" */
    oc_rep_set_boolean(root, value, g_binaryswitch_value); 
    PRINT("   %s : %d\n", g_binaryswitch_RESOURCE_PROPERTY_NAME_value,  g_binaryswitch_value );  /* not handled value */
    break;
  default:
    break;
  }
  oc_rep_end_root_object();
  oc_send_response(request, OC_STATUS_OK);
}
 
/**
* get method for "/dimmingcold" resource.
* function is called to intialize the return values of the GET method.
* initialisation of the returned values are done from the global property values.
* Resource Description:
* This Resource describes a dimming function.
* The Property "dimmingSetting" is an integer showing the current dimming level.
* If Property "step" is present then it represents the increment between dimmer values.
* When the Property "range" is omitted, then the range is [0,100].
* A value of 0 means total dimming; a value of 100 means no dimming.
*
* @param request the request representation.
* @param interfaces the interface used for this call
* @param user_data the user data.
*/
static void
get_dimmingcold(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)user_data;  /* not used */
  /* TODO: SENSOR add here the code to talk to the HW if one implements a sensor.
     the call to the HW needs to fill in the global variable before it returns to this function here.
     alternative is to have a callback from the hardware that sets the global variables.
  
     The implementation always return everything that belongs to the resource.
     this implementation is not optimal, but is functionally correct and will pass CTT1.2.2 */
  
  PRINT("get_dimmingcold: interface %d\n", interfaces);
  oc_rep_start_root_object();
  switch (interfaces) {
  case OC_IF_BASELINE:
    /* fall through */
  case OC_IF_A:
  PRINT("   Adding Baseline info\n" );
    oc_process_baseline_interface(request->resource);
    /* property "dimmingSetting" */
    oc_rep_set_int(root, dimmingSetting, g_dimmingcold_dimmingSetting ); 
    PRINT("   %s : %d\n", g_dimmingcold_RESOURCE_PROPERTY_NAME_dimmingSetting, g_dimmingcold_dimmingSetting );  /* not handled dimmingSetting */
    break;
  default:
    break;
  }
  oc_rep_end_root_object();
  oc_send_response(request, OC_STATUS_OK);
}
 
/**
* get method for "/dimmingwarm" resource.
* function is called to intialize the return values of the GET method.
* initialisation of the returned values are done from the global property values.
* Resource Description:
* This Resource describes a dimming function.
* The Property "dimmingSetting" is an integer showing the current dimming level.
* If Property "step" is present then it represents the increment between dimmer values.
* When the Property "range" is omitted, then the range is [0,100].
* A value of 0 means total dimming; a value of 100 means no dimming.
*
* @param request the request representation.
* @param interfaces the interface used for this call
* @param user_data the user data.
*/
static void
get_dimmingwarm(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)user_data;  /* not used */
  /* TODO: SENSOR add here the code to talk to the HW if one implements a sensor.
     the call to the HW needs to fill in the global variable before it returns to this function here.
     alternative is to have a callback from the hardware that sets the global variables.
  
     The implementation always return everything that belongs to the resource.
     this implementation is not optimal, but is functionally correct and will pass CTT1.2.2 */
  
  PRINT("get_dimmingwarm: interface %d\n", interfaces);
  oc_rep_start_root_object();
  switch (interfaces) {
  case OC_IF_BASELINE:
    /* fall through */
  case OC_IF_A:
  PRINT("   Adding Baseline info\n" );
    oc_process_baseline_interface(request->resource);
    /* property "dimmingSetting" */
    oc_rep_set_int(root, dimmingSetting, g_dimmingwarm_dimmingSetting ); 
    PRINT("   %s : %d\n", g_dimmingwarm_RESOURCE_PROPERTY_NAME_dimmingSetting, g_dimmingwarm_dimmingSetting );  /* not handled dimmingSetting */
    break;
  default:
    break;
  }
  oc_rep_end_root_object();
  oc_send_response(request, OC_STATUS_OK);
}
 
/**
* post method for "/binaryswitch" resource.
* The function has as input the request body, which are the input values of the POST method.
* The input values (as a set) are checked if all supplied values are correct.
* If the input values are correct, they will be assigned to the global  property values.
* Resource Description:

*
* @param requestRep the request representation.
*/
static void
post_binaryswitch(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)interfaces;
  (void)user_data;
  bool error_state = false;
  PRINT("post_binaryswitch:\n");
  oc_rep_t *rep = request->request_payload;
  /* loop over the request document to check if all inputs are ok */
  while (rep != NULL) {
    PRINT("key: (check) %s \n", oc_string(rep->name));if (strcmp ( oc_string(rep->name), g_binaryswitch_RESOURCE_PROPERTY_NAME_value) == 0) {
      /* property "value" of type boolean exist in payload */
      if (rep->type != OC_REP_BOOL) {
        error_state = true;
        PRINT ("   property 'value' is not of type bool %d \n", rep->type);
      }
    }
    
    rep = rep->next;
  }
  /* if the input is ok, then process the input document and assign the global variables */
  if (error_state == false)
  {
    /* loop over all the properties in the input document */
    oc_rep_t *rep = request->request_payload;
    while (rep != NULL) {
      PRINT("key: (assign) %s \n", oc_string(rep->name));
      /* no error: assign the variables */
      if (strcmp ( oc_string(rep->name), g_binaryswitch_RESOURCE_PROPERTY_NAME_value)== 0) {
        /* assign "value" */
        g_binaryswitch_value = rep->value.boolean;
      }
      rep = rep->next;
    }
    /* set the response */
    PRINT("Set response \n");
    oc_rep_start_root_object();
    /*oc_process_baseline_interface(request->resource); */
    oc_rep_set_boolean(root, value, g_binaryswitch_value); 
    oc_rep_end_root_object();


    lightbulb_set_on(&g_binaryswitch_value);
    /* TODO: ACTUATOR add here the code to talk to the HW if one implements an actuator.
       one can use the global variables as input to those calls
       the global values have been updated already with the data from the request */
    
    oc_send_response(request, OC_STATUS_CHANGED);
  }
  else
  {
    /* TODO: add error response, if any */
    oc_send_response(request, OC_STATUS_NOT_MODIFIED);
  }
}
 
/**
* post method for "/dimmingcold" resource.
* The function has as input the request body, which are the input values of the POST method.
* The input values (as a set) are checked if all supplied values are correct.
* If the input values are correct, they will be assigned to the global  property values.
* Resource Description:
* Sets the desired dimming level.
*
* @param requestRep the request representation.
*/
static void
post_dimmingcold(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)interfaces;
  (void)user_data;
  bool error_state = false;
  PRINT("post_dimmingcold:\n");
  oc_rep_t *rep = request->request_payload;
  /* loop over the request document to check if all inputs are ok */
  while (rep != NULL) {
    PRINT("key: (check) %s \n", oc_string(rep->name));
    if (strcmp ( oc_string(rep->name), g_dimmingcold_RESOURCE_PROPERTY_NAME_dimmingSetting) == 0) {
      /* property "dimmingSetting" of type integer exist in payload */
      int value = rep->value.integer;
      if (rep->type != OC_REP_INT) {
        error_state = true;
        PRINT ("   property 'dimmingSetting' is not of type int %d \n", rep->type);
      }
      
      
    }
    rep = rep->next;
  }
  /* if the input is ok, then process the input document and assign the global variables */
  if (error_state == false)
  {
    /* loop over all the properties in the input document */
    oc_rep_t *rep = request->request_payload;
    while (rep != NULL) {
      PRINT("key: (assign) %s \n", oc_string(rep->name));
      /* no error: assign the variables */
      if (strcmp ( oc_string(rep->name), g_dimmingcold_RESOURCE_PROPERTY_NAME_dimmingSetting) == 0) {
        /* assign "dimmingSetting" */
        g_dimmingcold_dimmingSetting = rep->value.integer;
      }
      rep = rep->next;
    }
    /* set the response */
    PRINT("Set response %d\n",g_dimmingcold_dimmingSetting);
    oc_rep_start_root_object();
    /*oc_process_baseline_interface(request->resource); */
    oc_rep_set_int(root, dimmingSetting, g_dimmingcold_dimmingSetting ); 
    oc_rep_end_root_object();
    
    set_dimming_cold(g_dimmingcold_dimmingSetting);

    /* TODO: ACTUATOR add here the code to talk to the HW if one implements an actuator.
       one can use the global variables as input to those calls
       the global values have been updated already with the data from the request */
    
    oc_send_response(request, OC_STATUS_CHANGED);
  }
  else
  {
    /* TODO: add error response, if any */
    oc_send_response(request, OC_STATUS_NOT_MODIFIED);
  }
}
 
/**
* post method for "/dimmingwarm" resource.
* The function has as input the request body, which are the input values of the POST method.
* The input values (as a set) are checked if all supplied values are correct.
* If the input values are correct, they will be assigned to the global  property values.
* Resource Description:
* Sets the desired dimming level.
*
* @param requestRep the request representation.
*/
static void
post_dimmingwarm(oc_request_t *request, oc_interface_mask_t interfaces, void *user_data)
{
  (void)interfaces;
  (void)user_data;
  bool error_state = false;
  PRINT("post_dimmingwarm:\n");
  oc_rep_t *rep = request->request_payload;
  /* loop over the request document to check if all inputs are ok */
  while (rep != NULL) {
    PRINT("key: (check) %s \n", oc_string(rep->name));
    if (strcmp ( oc_string(rep->name), g_dimmingwarm_RESOURCE_PROPERTY_NAME_dimmingSetting) == 0) {
      /* property "dimmingSetting" of type integer exist in payload */
      int value = rep->value.integer;
      if (rep->type != OC_REP_INT) {
        error_state = true;
        PRINT ("   property 'dimmingSetting' is not of type int %d \n", rep->type);
      }
      
      
    }
    rep = rep->next;
  }
  /* if the input is ok, then process the input document and assign the global variables */
  if (error_state == false)
  {
    /* loop over all the properties in the input document */
    oc_rep_t *rep = request->request_payload;
    while (rep != NULL) {
      PRINT("key: (assign) %s \n", oc_string(rep->name));
      /* no error: assign the variables */
      if (strcmp ( oc_string(rep->name), g_dimmingwarm_RESOURCE_PROPERTY_NAME_dimmingSetting) == 0) {
        /* assign "dimmingSetting" */
        g_dimmingwarm_dimmingSetting = rep->value.integer;
      }
      rep = rep->next;
    }
    /* set the response */
    PRINT("Set response %d\n",g_dimmingwarm_dimmingSetting);
    oc_rep_start_root_object();
    /*oc_process_baseline_interface(request->resource); */
    oc_rep_set_int(root, dimmingSetting, g_dimmingwarm_dimmingSetting ); 
    oc_rep_end_root_object();
    

    set_dimming_warm(g_dimmingwarm_dimmingSetting);
    /* TODO: ACTUATOR add here the code to talk to the HW if one implements an actuator.
       one can use the global variables as input to those calls
       the global values have been updated already with the data from the request */
    
    oc_send_response(request, OC_STATUS_CHANGED);
  }
  else
  {
    /* TODO: add error response, if any */
    oc_send_response(request, OC_STATUS_NOT_MODIFIED);
  }
}
/**
* register all the resources to the stack
* this function registers all application level resources:
* - each resource path is bind to a specific function for the supported methods (GET, POST, PUT)
* - each resource is 
*   - secure
*   - observable
*   - discoverable 
*   - used interfaces (from the global variables).
*/
static void
register_resources(void)
{

  PRINT("Register Resource with local path \"/binaryswitch\"\n");
  oc_resource_t *res_binaryswitch = oc_new_resource(NULL, g_binaryswitch_RESOURCE_ENDPOINT, g_binaryswitch_nr_resource_types, 0);
  PRINT("     number of Resource Types: %d\n", g_binaryswitch_nr_resource_types);
  for( int a = 0; a < g_binaryswitch_nr_resource_types; a++ ) {
    PRINT("     Resource Type: \"%s\"\n", g_binaryswitch_RESOURCE_TYPE[a]);
    oc_resource_bind_resource_type(res_binaryswitch,g_binaryswitch_RESOURCE_TYPE[a]);
  }
  for( int a = 0; a < g_binaryswitch_nr_resource_interfaces; a++ ) {
    oc_resource_bind_resource_interface(res_binaryswitch, convert_if_string(g_binaryswitch_RESOURCE_INTERFACE[a]));
  }
  oc_resource_set_default_interface(res_binaryswitch, convert_if_string(g_binaryswitch_RESOURCE_INTERFACE[0]));  
  PRINT("     Default OCF Interface: \"%s\"\n", g_binaryswitch_RESOURCE_INTERFACE[0]);
  oc_resource_set_discoverable(res_binaryswitch, true);
  /* periodic observable
     to be used when one wants to send an event per time slice
     period is 1 second */
  oc_resource_set_periodic_observable(res_binaryswitch, 1);
  /* set observable
     events are send when oc_notify_observers(oc_resource_t *resource) is called.
    this function must be called when the value changes, perferable on an interrupt when something is read from the hardware. */
  /*oc_resource_set_observable(res_binaryswitch, true); */
   
  oc_resource_set_request_handler(res_binaryswitch, OC_GET, get_binaryswitch, NULL);
   
  oc_resource_set_request_handler(res_binaryswitch, OC_POST, post_binaryswitch, NULL);
  oc_add_resource(res_binaryswitch);

  PRINT("Register Resource with local path \"/dimmingcold\"\n");
  oc_resource_t *res_dimmingcold = oc_new_resource(NULL, g_dimmingcold_RESOURCE_ENDPOINT, g_dimmingcold_nr_resource_types, 0);
  PRINT("     number of Resource Types: %d\n", g_dimmingcold_nr_resource_types);
  for( int a = 0; a < g_dimmingcold_nr_resource_types; a++ ) {
    PRINT("     Resource Type: \"%s\"\n", g_dimmingcold_RESOURCE_TYPE[a]);
    oc_resource_bind_resource_type(res_dimmingcold,g_dimmingcold_RESOURCE_TYPE[a]);
  }
  for( int a = 0; a < g_dimmingcold_nr_resource_interfaces; a++ ) {
    oc_resource_bind_resource_interface(res_dimmingcold, convert_if_string(g_dimmingcold_RESOURCE_INTERFACE[a]));
  }
  oc_resource_set_default_interface(res_dimmingcold, convert_if_string(g_dimmingcold_RESOURCE_INTERFACE[0]));  
  PRINT("     Default OCF Interface: \"%s\"\n", g_dimmingcold_RESOURCE_INTERFACE[0]);
  oc_resource_set_discoverable(res_dimmingcold, true);
  /* periodic observable
     to be used when one wants to send an event per time slice
     period is 1 second */
  oc_resource_set_periodic_observable(res_dimmingcold, 1);
  /* set observable
     events are send when oc_notify_observers(oc_resource_t *resource) is called.
    this function must be called when the value changes, perferable on an interrupt when something is read from the hardware. */
  /*oc_resource_set_observable(res_dimmingcold, true); */
   
  oc_resource_set_request_handler(res_dimmingcold, OC_GET, get_dimmingcold, NULL);
   
  oc_resource_set_request_handler(res_dimmingcold, OC_POST, post_dimmingcold, NULL);
  oc_add_resource(res_dimmingcold);

  PRINT("Register Resource with local path \"/dimmingwarm\"\n");
  oc_resource_t *res_dimmingwarm = oc_new_resource(NULL, g_dimmingwarm_RESOURCE_ENDPOINT, g_dimmingwarm_nr_resource_types, 0);
  PRINT("     number of Resource Types: %d\n", g_dimmingwarm_nr_resource_types);
  for( int a = 0; a < g_dimmingwarm_nr_resource_types; a++ ) {
    PRINT("     Resource Type: \"%s\"\n", g_dimmingwarm_RESOURCE_TYPE[a]);
    oc_resource_bind_resource_type(res_dimmingwarm,g_dimmingwarm_RESOURCE_TYPE[a]);
  }
  for( int a = 0; a < g_dimmingwarm_nr_resource_interfaces; a++ ) {
    oc_resource_bind_resource_interface(res_dimmingwarm, convert_if_string(g_dimmingwarm_RESOURCE_INTERFACE[a]));
  }
  oc_resource_set_default_interface(res_dimmingwarm, convert_if_string(g_dimmingwarm_RESOURCE_INTERFACE[0]));  
  PRINT("     Default OCF Interface: \"%s\"\n", g_dimmingwarm_RESOURCE_INTERFACE[0]);
  oc_resource_set_discoverable(res_dimmingwarm, true);
  /* periodic observable
     to be used when one wants to send an event per time slice
     period is 1 second */
  oc_resource_set_periodic_observable(res_dimmingwarm, 1);
  /* set observable
     events are send when oc_notify_observers(oc_resource_t *resource) is called.
    this function must be called when the value changes, perferable on an interrupt when something is read from the hardware. */
  /*oc_resource_set_observable(res_dimmingwarm, true); */
   
  oc_resource_set_request_handler(res_dimmingwarm, OC_GET, get_dimmingwarm, NULL);
   
  oc_resource_set_request_handler(res_dimmingwarm, OC_POST, post_dimmingwarm, NULL);
  oc_add_resource(res_dimmingwarm);
}

/**
* signal the event loop (Linux)
* wakes up the main function to handle the next callback
*/
static void
signal_event_loop(void)
{
  pthread_mutex_lock(&mutex);
  pthread_cond_signal(&cv);
  pthread_mutex_unlock(&mutex);
}

/**
* handle Ctrl-C
* @param signal the captured signal
*/
void
handle_signal(int signal)
{
  (void)signal;
  signal_event_loop();
  quit = 1;
}

/**
* main application.
* intializes the global variables
* registers and starts the handler
* handles (in a loop) the next event.
* shuts down the stack
*/
int server_main(void)
{
int init;

  /* linux specific */
  //struct sigaction sa;
  //sigfillset(&sa.sa_mask);
  //sa.sa_flags = 0;
  //sa.sa_handler = handle_signal;
  /* install Ctrl-C */
  //sigaction(SIGINT, &sa, NULL);
  /* initialize global variables for resource "/binaryswitch" */
  g_binaryswitch_value = false; /* current value of property "value" The status of the switch. */
  
  /* initialize global variables for resource "/dimmingcold" */
  g_dimmingcold_dimmingSetting = 30; /* current value of property "dimmingSetting" The current dimming value. */
  
  /* initialize global variables for resource "/dimmingwarm" */
  g_dimmingwarm_dimmingSetting = 30; /* current value of property "dimmingSetting" The current dimming value. */
  /* set the flag for NO oic/con resource. */
  oc_set_con_res_announced(false);

  // ================ Section Copied from server_freertos.c ==========================

  tcpip_adapter_ip_info_t ip4_info = { 0 };
  struct ip6_addr if_ipaddr_ip6 = { 0 };
  PRINT("===     iotivity server task started");
  // wait to fetch IPv4 && ipv6 address
  EventGroupHandle_t net_event_group = getEventGroup();
#ifdef OC_IPV4
  xEventGroupWaitBits(net_event_group, IPV4_CONNECTED_BIT, false, true, portMAX_DELAY);
#else
  xEventGroupWaitBits(net_event_group, IPV6_CONNECTED_BIT, false, true, portMAX_DELAY);
#endif

  if ( tcpip_adapter_get_ip_info(ESP_IF_ETH, &ip4_info) != ESP_OK) {
      PRINT("get IPv4 address failed");
  } else {
      PRINT("=== got IPv4 addr:%s", ip4addr_ntoa(&(ip4_info.ip)));
  }

#ifndef OC_IPV4
  if ( tcpip_adapter_get_ip6_linklocal(ESP_IF_ETH, &if_ipaddr_ip6) != ESP_OK) {
      PRINT("get IPv6 address failed");
  } else {
      PRINT("=== got IPv6 addr:%s", ip6addr_ntoa(&if_ipaddr_ip6));
  }
#endif
    // ==================================================================================

  /* initializes the handlers structure */
  static const oc_handler_t handler = {.init = app_init,
                                       .signal_event_loop = signal_event_loop,
                                       .register_resources = register_resources
#ifdef OC_CLIENT
                                       ,
                                       .requests_entry = 0 
#endif
                                       };
  oc_clock_time_t next_event;
  
  PRINT("Used input file : \"../device_output/out_codegeneration_merged.swagger.json\"\n");
  PRINT("OCF Server name : \"Binary Switch\"\n");

#ifdef OC_SECURITY
  PRINT("Intialize Secure Resources\n");
  oc_storage_config("/creds/");
#endif /* OC_SECURITY */


  /* start the stack */
  init = oc_main_init(&handler);
  if (init < 0)
    return init;

  PRINT("OCF server \"Binary Switch\" running, waiting on incomming connections.\n");
    
  /* linux specific loop */
  while (1) {
    next_event = oc_main_poll();
    pthread_mutex_lock(&mutex);
    if (next_event == 0) {
      pthread_cond_wait(&cv, &mutex);
    } else {
      ts.tv_sec = (next_event / OC_CLOCK_SECOND);
      ts.tv_nsec = (next_event % OC_CLOCK_SECOND) * 1.e09 / OC_CLOCK_SECOND;
      pthread_cond_timedwait(&cv, &mutex, &ts);
    }
    pthread_mutex_unlock(&mutex);
  }

  /* shut down the stack */
  oc_main_shutdown();
  return 0;
}

void app_main(void)
{
    if (nvs_flash_init() != ESP_OK){
        PRINT("===!!! nvs_flash_init failed");
    }

    pthread_cond_init(&cv, NULL);

    //print_macro_info();

    if(initEthernet() != ESP_OK) {
        printf("[ \033[31mERROR\033[0m ]\n");
        esp_eth_disable();
    }

    if ( xTaskCreate(&server_main, "server_main", 15*1024, NULL, 5, NULL) != pdPASS ) {
        PRINT("===!!! task create failed");
    }

    if ( xTaskCreate(&lightbulb_damon_task, "lightbulb_damon_task", 8192, NULL, 5, NULL) != pdPASS ) {
        PRINT("===!!! task create failed");
    }
}

